<?php

namespace Database\Seeders;

use App\Models\Card;
use Illuminate\Database\Seeder;

class CardSeeder extends Seeder
{
    public function run(): void
    {
        foreach (Card::SUITS as $suit) {
            foreach (Card::RANKS as $rank) {
                Card::firstOrCreate(['rank' => $rank, 'suit' => $suit]);
            }
        }
    }
}
