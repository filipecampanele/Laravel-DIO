<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cards', function (Blueprint $table) {
            $table->id();
            $table->string('rank', 2);
            $table->string('suit', 10);
            $table->timestamps();

            $table->unique(['rank', 'suit']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cards');
    }
};
