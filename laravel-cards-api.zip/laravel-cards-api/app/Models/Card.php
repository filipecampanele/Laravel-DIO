<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Card extends Model
{
    public const SUITS = ['hearts', 'diamonds', 'clubs', 'spades'];
    public const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

    protected $fillable = ['rank', 'suit'];

    public function getColorAttribute(): string
    {
        return in_array($this->suit, ['hearts', 'diamonds']) ? 'red' : 'black';
    }

    public function getIsFaceCardAttribute(): bool
    {
        return in_array($this->rank, ['J', 'Q', 'K']);
    }

    public function getPointsAttribute(): int
    {
        return match (true) {
            $this->rank === 'A' => 1,
            $this->is_face_card => 10,
            default => (int) $this->rank,
        };
    }
}
