<?php

namespace App\Http\Requests;

use App\Models\Card;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CardRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $ignoreId = $this->route('card')?->id;

        return [
            'rank' => ['required', Rule::in(Card::RANKS)],
            'suit' => [
                'required',
                Rule::in(Card::SUITS),
                Rule::unique('cards')
                    ->where('rank', $this->input('rank'))
                    ->ignore($ignoreId),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'rank.required' => 'O valor da carta é obrigatório.',
            'rank.in' => 'Valor inválido. Use: ' . implode(', ', Card::RANKS) . '.',
            'suit.required' => 'O naipe é obrigatório.',
            'suit.in' => 'Naipe inválido. Use: ' . implode(', ', Card::SUITS) . '.',
            'suit.unique' => 'Essa carta já está cadastrada.',
        ];
    }
}
