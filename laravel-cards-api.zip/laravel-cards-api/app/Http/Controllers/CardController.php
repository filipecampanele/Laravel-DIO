<?php

namespace App\Http\Controllers;

use App\Http\Requests\CardRequest;
use App\Http\Resources\CardResource;
use App\Models\Card;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class CardController extends Controller
{
    // GET /api/cards?suit=hearts
    public function index(Request $request): AnonymousResourceCollection
    {
        $cards = Card::query()
            ->when($request->query('suit'), fn ($q, $suit) => $q->where('suit', $suit))
            ->orderBy('id')
            ->paginate(15);

        return CardResource::collection($cards);
    }

    // POST /api/cards
    public function store(CardRequest $request): JsonResponse
    {
        $card = Card::create($request->validated());

        return (new CardResource($card))->response()->setStatusCode(201);
    }

    // GET /api/cards/{id}
    public function show(Card $card): CardResource
    {
        return new CardResource($card);
    }

    // PUT/PATCH /api/cards/{id}
    public function update(CardRequest $request, Card $card): CardResource
    {
        $card->update($request->validated());

        return new CardResource($card);
    }

    // DELETE /api/cards/{id}
    public function destroy(Card $card): Response
    {
        $card->delete();

        return response()->noContent();
    }

    // GET /api/cards/{id}/info  -> informações adicionais por ID
    public function info(Card $card): JsonResponse
    {
        return response()->json([
            'id' => $card->id,
            'name' => "{$card->rank} of " . ucfirst($card->suit),
            'color' => $card->color,
            'is_face_card' => $card->is_face_card,
            'points' => $card->points,
        ]);
    }
}
