# API de Baralho com Laravel

API REST feita do zero com Laravel (rotas, controller, consultas por ID e validação).

## Requisitos
- PHP 8.2+
- Composer
- SQLite (padrão do Laravel 11/12) ou MySQL

## Instalação

```bash
# 1. Criar o projeto Laravel
composer create-project laravel/laravel cards-api
cd cards-api

# 2. Habilitar o arquivo routes/api.php
php artisan install:api

# 3. Copiar os arquivos deste pacote por cima do projeto
#    (routes/, app/, database/, tests/)

# 4. Migrar e popular o baralho (52 cartas)
php artisan migrate
php artisan db:seed --class=CardSeeder

# 5. Subir o servidor
php artisan serve
```

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
| GET | /api/cards | Lista cartas (filtro `?suit=hearts`) |
| POST | /api/cards | Cadastra carta (com validação) |
| GET | /api/cards/{id} | Busca carta por ID |
| PUT/PATCH | /api/cards/{id} | Atualiza carta |
| DELETE | /api/cards/{id} | Remove carta |
| GET | /api/cards/{id}/info | Informações adicionais (cor, pontos, figura) |

Naipes: `hearts`, `diamonds`, `clubs`, `spades`
Valores: `A, 2-10, J, Q, K`

## Exemplos

```bash
curl -X POST http://localhost:8000/api/cards \
  -H "Accept: application/json" -H "Content-Type: application/json" \
  -d '{"rank":"A","suit":"spades"}'

curl -H "Accept: application/json" http://localhost:8000/api/cards/1/info
```

Sempre envie o header `Accept: application/json` para receber erros de validação em JSON.

## Testes
```bash
php artisan test
```
