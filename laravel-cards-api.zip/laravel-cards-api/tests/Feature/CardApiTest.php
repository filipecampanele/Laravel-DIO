<?php

namespace Tests\Feature;

use App\Models\Card;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CardApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_create_card(): void
    {
        $this->postJson('/api/cards', ['rank' => 'A', 'suit' => 'spades'])
            ->assertCreated()
            ->assertJsonPath('data.rank', 'A');
    }

    public function test_validation_rejects_invalid_data(): void
    {
        $this->postJson('/api/cards', ['rank' => '99', 'suit' => 'stars'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['rank', 'suit']);
    }

    public function test_rejects_duplicate_card(): void
    {
        Card::create(['rank' => 'K', 'suit' => 'hearts']);

        $this->postJson('/api/cards', ['rank' => 'K', 'suit' => 'hearts'])
            ->assertUnprocessable();
    }

    public function test_info_by_id(): void
    {
        $card = Card::create(['rank' => 'Q', 'suit' => 'hearts']);

        $this->getJson("/api/cards/{$card->id}/info")
            ->assertOk()
            ->assertJson(['color' => 'red', 'is_face_card' => true, 'points' => 10]);
    }

    public function test_show_returns_404_when_missing(): void
    {
        $this->getJson('/api/cards/999')->assertNotFound();
    }

    public function test_can_update_and_delete(): void
    {
        $card = Card::create(['rank' => '5', 'suit' => 'clubs']);

        $this->putJson("/api/cards/{$card->id}", ['rank' => '6', 'suit' => 'clubs'])->assertOk();
        $this->deleteJson("/api/cards/{$card->id}")->assertNoContent();
    }
}
