<?php

use App\Http\Controllers\CardController;
use Illuminate\Support\Facades\Route;

Route::get('/cards/{card}/info', [CardController::class, 'info']);
Route::apiResource('cards', CardController::class);
